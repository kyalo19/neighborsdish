package com.kyalo.neighboursdish;

import android.graphics.Bitmap;

public class FirebaseStorage {

    @org.jetbrains.annotations.Nullable
    @org.jetbrains.annotations.Contract(pure = true)
    public static Bitmap loadImage(String url){
        return null;
    }

    public static void saveImage(String url, Bitmap image){

    }
}
