package com.kyalo.neighboursdish.AddDish;

public class ObjectDishCategory {

    public String name;
    public int image;
    public boolean state;


    // Constructor.
    public ObjectDishCategory(String name, int image, boolean state) {

        this.name = name;
        this.image = image;
        this.state = state;


    }





}